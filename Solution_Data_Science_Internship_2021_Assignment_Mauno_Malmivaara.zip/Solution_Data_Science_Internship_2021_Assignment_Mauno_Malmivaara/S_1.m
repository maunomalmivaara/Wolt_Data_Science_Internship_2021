clear
close all
order_data = readtable('orders_autumn_2020.csv');

% Get number of orders made per each day of the week:
[daynames, orders_per_day_of_week] = get_orders_per_day_of_week(order_data);

% Separate all orders into ones made on weekdays and
% ones made on weekends:
[orders_made_on_weekdays, ...
    orders_made_on_weekends] = get_orders_separated_by_weekend(order_data);

% Get orders per hour, normalised to represent an average (weekday/weekend) day:
norm_wkd_hours = get_norm_hours(orders_made_on_weekdays);
norm_wknd_hours = get_norm_hours(orders_made_on_weekends);

% Hours of the day:
hours = 0:23;

% Plot the number of orders made on each day of the week:
figure
bar(orders_per_day_of_week)
set(gca,'xticklabel',daynames')
xlabel('Day')
ylabel('No. of Orders')
title('Orders Per Weekday')

figure
subplot(2, 1, 1)
bar(norm_wkd_hours)
xlim([0, 23.5])
xticks(hours)
title('Orders made on an average weekday day')
ylim([0, 40])
xlabel('Time of day (hours)')
ylabel('No. of orders')

subplot(2, 1, 2)
bar(norm_wknd_hours)
xlim([0, 23.5])
xticks(hours)
title('Orders made on an average weekend day')
ylim([0, 40])
xlabel('Time of day (hours)')
ylabel('No. of orders')


