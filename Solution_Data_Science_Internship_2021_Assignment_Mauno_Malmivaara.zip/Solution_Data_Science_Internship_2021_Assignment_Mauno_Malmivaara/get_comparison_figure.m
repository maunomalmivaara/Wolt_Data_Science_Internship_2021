function fig = get_comparison_figure(input_data, nbins, xmax, ymax, title_text)
    % This function returns a figure which compares the input data
    % to a corresponding exponential distribution
    
    fig = figure;
    % Draw the order input_data normalised to their
    % appearance probabilities:
    histogram(input_data, nbins, 'Normalization','probability');

    % Draw actual exponential distribution ontop of the
    % histogram for comparison:
    hold on
    x = min(input_data):max(input_data);
    % Mean of exponential distribution:
    mu = expfit(input_data);
    % Draw actual exponential distribution:
    plot(x, exppdf(x, mu), 'LineWidth', 2);

    legend('Observations', ['Exponential distribution (mean = ', num2str(mu), ')'])
    xlabel('Time between orders (minutes)')
    ylabel('Probability')
    xlim([0, xmax])
    ylim([0, ymax])
    title(title_text)
end

