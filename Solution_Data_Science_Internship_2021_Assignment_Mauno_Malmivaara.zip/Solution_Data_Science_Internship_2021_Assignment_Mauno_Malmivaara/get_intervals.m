function return_intervals = get_intervals(orders)
    % This is a function for getting the times between orders (intervals).

    % Extract timestamps:
    timestamps = orders.TIMESTAMP;
    
    % Group orders by their date:
    day_groups = get_groupped_by_date(orders);
    
    % No of unique groups (dates):
    no_of_dates = day_groups(length(day_groups));

    % Array for intervals between orders:
    intervals = duration(nan(length(timestamps), 3));

    % Go through each unique date. For each date, get all orders
    % made on that day. For each order made on that day,
    % starting from the second, check how much time had passed
    % from the previous order when this one was made (the interval).
    % Add this interval to intervals array.
    % By going through each date separately, it takes into account the
    % nights and won't add them as intervals.
    for i = 1 : no_of_dates

        orders_on_this_date = timestamps(day_groups == i);
        no_of_orders = length(orders_on_this_date);

        for j = 2 : no_of_orders  
            interval_index = length(intervals(~isnan(intervals))) + 1;

            intervals(interval_index) = orders_on_this_date(j) ...
                - orders_on_this_date(j - 1);
        end
    end

    % Remove NaNs:
    intervals = intervals(~isnan(intervals));
    
    % Convert datatype to double and return:
    return_intervals = minutes(intervals);
end

