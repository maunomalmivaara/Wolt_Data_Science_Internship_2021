function groups = get_groupped_by_date(orders)
    % This function groups orders by dates.

    % Extract timestamps:
    timestamps = orders.TIMESTAMP;
    % Round the timestamps to dates for grouping:
    timestamps_rounded_to_day = datetime(year(timestamps),...
                                                month(timestamps),...
                                                day(timestamps)...
                                            );
    % Group rounded timestamps by date:
    groups = findgroups(timestamps_rounded_to_day);
end

