function nof_days = get_nof_distinct_days(orders)
    % This function returns the number of distinct days in a table of
    % orders.

    % Group orders into dates:
    wkd_day_groups = get_groupped_by_date(orders);
    % Find out no. of weekday days:
    nof_days = wkd_day_groups(length(wkd_day_groups));
end