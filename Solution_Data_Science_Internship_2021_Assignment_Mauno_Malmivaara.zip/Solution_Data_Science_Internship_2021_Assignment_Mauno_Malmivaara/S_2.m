clear
close all

order_data = readtable('orders_autumn_2020.csv');

% Delivery times:
delivery_times = order_data.ACTUAL_DELIVERY_MINUTES;

% Orders separated to the those made on weekdays
% and those made on weekends:
[orders_made_on_weekdays,...
    orders_made_on_weekends] = get_orders_separated_by_weekend(order_data);

% Times inbetween orders (intervals):
order_intervals_wkd = get_intervals(orders_made_on_weekdays);
order_intervals_wknd = get_intervals(orders_made_on_weekends);

% Means for the exponential distributions of order intervals:
mean_order_interval_wkd = expfit(order_intervals_wkd);
mean_order_interval_wknd = expfit(order_intervals_wknd);

% Delivery time mean for its exponential distribution:
mean_delivery_time = expfit(delivery_times);
max_couriers = 25;
nof_loops = 10;

% Simulate order queue length with 1 to 25 couriers standing by,
% 10 iterations each:

% Weekdays:
get_monte_carlo_figure(mean_order_interval_wkd, ...
    mean_delivery_time, max_couriers, nof_loops)

% Weekends:
get_monte_carlo_figure(mean_order_interval_wknd, ...
    mean_delivery_time, max_couriers, nof_loops)


