clear
close all
order_data = readtable('orders_autumn_2020.csv');


% Get delivery times:
delivery_times = order_data.ACTUAL_DELIVERY_MINUTES;

mu = mean(delivery_times);
sd = std(delivery_times);

figure
% Draw the order intervals normalised to their
% appearance probabilities:
histogram(delivery_times, 52, 'Normalization','probability');

% Draw actual exponential distribution ontop of the
% histogram for comparison:
hold on
x = min(delivery_times):max(delivery_times);
% Mean:
pd = fitdist(delivery_times,'Normal');

plot(x, pdf(pd, x), 'LineWidth', 2);

legend('Observations', ['Normal distribution ~N(', num2str(pd.mu), ', ', num2str(pd.sigma), ')'])
title('Delivery times')
xlabel('Delivery time (minutes)')
ylabel('Probability')
xlim([0, 70])