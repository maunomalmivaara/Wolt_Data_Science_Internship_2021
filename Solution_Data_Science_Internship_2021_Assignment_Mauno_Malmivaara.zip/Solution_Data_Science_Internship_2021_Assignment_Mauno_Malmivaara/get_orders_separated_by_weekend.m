function [weekday_orders, weekend_orders] = get_orders_separated_by_weekend(orders)
    % This is a function for separating an order table into two tables:
    % one containing orders made on weekdays, and another containing orders
    % made on weekends.
    
    % Logical matrix for whether an order was made on a weekend:
    is_on_weekend = isweekend(orders.TIMESTAMP);
    
	% Take corresponding rows of the order table:
    weekday_orders = orders(~is_on_weekend, :);
    weekend_orders = orders(is_on_weekend, :);
end

