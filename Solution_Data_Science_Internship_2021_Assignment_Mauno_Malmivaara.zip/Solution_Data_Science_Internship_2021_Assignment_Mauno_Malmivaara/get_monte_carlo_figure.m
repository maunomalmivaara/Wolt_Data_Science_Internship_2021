function fig = get_monte_carlo_figure(...
    order_interval_mean,...
    delivery_time_mean,...
    max_couriers,...
    nof_loops)

    % This is a function for getting the simulation figure.

    fig = figure;
    
    % Loop over scenarios, in which the number of couriers changes:
    for nof_couriers = (1:max_couriers)

        % Draw people_in_queue subplot for each number of couriers:
        subplot(5, 5, nof_couriers)
        hold on

        % Repeat the (pseudo) random process [nof_loops] times 
        % in order to produce reliability:
        for loop = 1:nof_loops

            % Current order queue length. Starts at 0 people.
            people_in_queue = 0;
            % Current time. Starts at 0 minutes,
            time = 0;

            % Initialise vectors for time ticks and queue updates:
            time_ticks = [time];
            queue = [people_in_queue];

            % Loop over the minutes of a day:
            while time <= 8 * 60

                % Time it takes until next order is placed, according
                % to their exponential distribution:
                time_until_next_order_is_placed = exprnd(order_interval_mean);

                % Finishing deliveries (freeing couriers):
                nof_occupied_couriers = min(people_in_queue, nof_couriers);
                
                % If there are on going deliveries, find the time
                % it takes for the next one to finish. If not, set
                % that time to equel infinity:
                if nof_occupied_couriers > 0
                    % Time it takes until each ongoing delivery is finished,
                    % according to their exponential distribution:
                    delivery_finish_times_all_couriers = exprnd(delivery_time_mean, nof_occupied_couriers, 1);
                    % Time it takes until NEXT delivery will finish:
                    time_until_next_delivery_finishes = min(delivery_finish_times_all_couriers);
                else
                    % If no deliveries are currently happening:
                    time_until_next_delivery_finishes = Inf;
                end

                % Update current time:
                time = time + min(time_until_next_order_is_placed, time_until_next_delivery_finishes);
                
                % Log time for plotting:
                time_ticks(end + 1, 1) = time;

                if time_until_next_delivery_finishes < time_until_next_order_is_placed
                    people_in_queue = people_in_queue - 1;
                else
                    people_in_queue = people_in_queue + 1;
                end

                % Log queue length for plotting:
                queue = [queue; max(people_in_queue-nof_couriers, 0)];
            end

            % Plot:
            stairs(time_ticks, queue)
        end

        title([num2str(nof_couriers), ' couriers'])
        xlabel('Time (mins)')
        ylabel('Queue length')
        ylim([0 inf])
    end
end

