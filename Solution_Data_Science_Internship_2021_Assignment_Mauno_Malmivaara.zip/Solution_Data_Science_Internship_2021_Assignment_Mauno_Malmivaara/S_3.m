clear
close all
order_data = readtable('orders_autumn_2020.csv');

% Get times inbetween orders (intervals):
intervals = get_intervals(order_data);

% Get delivery times:
delivery_times = order_data.ACTUAL_DELIVERY_MINUTES;

% Compare their distributions to exponential distributions:

% Intervals:
get_comparison_figure(intervals, 100, 30, 0.7, 'Order Intervals');

% Delivery times:
get_comparison_figure(delivery_times, 52, 60, 0.05, 'Delivery Times');