Wolt’s Data Science Summer Internship 2021 Assignment
Mauno Malmivaara


My approach:

My solution optimises the amount of stand-by food couriers by performing a Monte Carlo simulation on MATLAB.

File naming:

Files with prefix "S" (e.g. S_1.m) are scripts that perform the broader tasks. To replicate my graphs, run these files. Files with prefix "get" are functions which perform smaller tasks.


 - Exploration and Modelling:

1. Filename: S_1.m

I first wanted to find out how the orders are distributed over the days of the week. As expected, more orders were made on weekends (Sat, Sun) than on weekdays (Mon, Tue, Wed, Thu, Fri). To further investigate this difference, I separated the orders into ones made on weekdays and ones made on weekends. I plotted the orders by the hour on which they were made. The distributions were vastly different between the two order categories, so I decided to treat them as separate chunks to make the model more accurate. An interesting finding was that there was no lunch-time peak in order frequency on weekdays.

[graph]
[graph]

2. Filename: S_2.m

This script is where the Monte Carlo Simulation occurs. My model assumes that the times in-between orders and the delivery times are exponentially distributed, that is, they are not dependent on the previous occurrence (exponential distribution has a memory loss property).

My simulation produces a 5x5 grid of graphs, which are representations of scenarios with different amounts of available food couriers. A graph represents the length of an order queue, in which the x-axis is time in minutes and y-axis is queue length. Two grids are made to treat weekdays and weekends separately.

DILEMMA: On the one hand, we want the queue to be as short as possible, but on the other hand, we can't be paying infinitely many couriers for standing by for orders.

RESULTS:
As can be seen from the grid, the more couriers there are, the shorter the order queue is over the course of the day. If there are only a few couriers, the order queue just keeps on growing. If there are many couriers, the length of the queue is managed.

According to the simulation, to keep the length of the order queue below, say 10 people, the number of stand-by couriers should be around 14-17 on weekdays and around 17-20. 


Order queues on weekdays:
[graph]
Order queues on weekends:
[graph]



3. Filename: S_3.m

After completing my Monte Carlo algorithm, I started to question whether my data is actually exponentially distributed. This script compares the data to an exponential distribution with the same mean.

Order Intervals (the times in-between orders):
[graph]
 
As can be seen from the graph, the order intervals match very well with an exponential distribution with the same mean.

Delivery times (= the times that couriers are occupied and cannot serve new customers)
[graph]


As can be seen from the graph, the delivery times do not match with an exponential distribution.
The model I created works only if the data is exponentially distributed. The delivery times probably would be close to exponentially distributed if most couriers were in a city centre and if most orders were placed in close proximity of the city centre.


4. Filename S_4.m

The delivery times look close to normally distributed. This script just compares them to a normal distribution with same mean and standard deviation.

[graph]
As can be seen from the graph, the distributions match fairly well.




Assumptions:
-	Orders were made in the same city, within close proximity of city centre (hence the exponential distribution). This is backed up by coordinates.
-	Delivery times are not affected by time of week (weekday / weekend)
-	One courier can be taking care of max. one order at a given time

Limitations:
-	Delivery times were not exponentially distributed.
-	The model does not account for transitions in-between deliveries.



Evaluation

I’m quite happy with my efforts on the assignment. The simulation works as expected. One thing I’m not happy about is the distribution assumption of delivery times. I didn’t have time to change the model to account for the fact that the delivery times are normally distributed, rather than exponentially distributed. This would also make the algorithm more complicated, as a normal distribution does not have a memory loss property, and hence cannot be used similarly in a loop.

An implementation of this model could be useful for Wolt, should the collective labor agreements for couriers change to obligate a more traditional contract of employment with hourly pay.


Further Development

If I had the time and resources, I’d change the algorithm to account for the normal distribution of the delivery times. I’d also run it more times to produce reliability. I’d also create some optimisable function that takes in queue length and the number of couriers as inputs.









