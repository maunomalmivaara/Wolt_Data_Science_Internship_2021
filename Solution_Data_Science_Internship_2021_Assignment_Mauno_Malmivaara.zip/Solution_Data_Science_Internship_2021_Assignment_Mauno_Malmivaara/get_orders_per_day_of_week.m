function [day_names, order_count] = get_orders_per_day_of_week(orders)
    % This function returns the number of orders made on each weekday.

    [order_day_numbers, order_day_names] = weekday(orders.TIMESTAMP);
    % Convert days from chars to strings and transpose:
    order_day_names = string(order_day_names).';
    
    daynames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    orders_per_weekday = zeros(1, 7);
    
%   Go through each weekday:
    for i = 1:7
        count = 0; % Incrementer
%       Go though each order and check if they were made on the
%       current weekday:
        for j = 1:length(order_day_names)
%           If the names match, increment:
            if (order_day_names(:, j) == daynames(i))
                count = count + 1;
            end
        end
%       Add incrementer to array:
        orders_per_weekday(i) = count;
    end
%   Return:
    day_names = daynames;
    order_count = orders_per_weekday;
end

