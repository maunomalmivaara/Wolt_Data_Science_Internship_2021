function order_count = get_orders_per_hour(orders)
    % This function returns the number of orders made on each hour.

    [order_hours, order_minutes, order_seconds] = hms(orders.TIMESTAMP);

    hrs = 0:23;
    orders_per_hour = zeros(1, 24);
    
%   Go through each hour:
    for i = hrs
        count = 0; % Incrementer
%       Go though each order and check if they were made on the
%       current hour:
        for j = 1:length(order_hours)
%           If the hours match, increment:
            if (order_hours(j) == i)
                count = count + 1;
            end
        end
%       Add incrementer to array:
        orders_per_hour(i + 1) = count;
    end
%   Return:
    order_count = orders_per_hour;
end

