function norm_hours = get_norm_hours(orders)
    % This function takes in a table of orders and returns the orders
    % made per hour on average.


    % Orders made per each hour:
    orders_per_hour = get_orders_per_hour(orders);

    % Number of distinct days:
    nof_days = get_nof_distinct_days(orders);

    % Normalize orders-by-hour data by dividing with number of
    % distinct days, to represent one "average" day:
    norm_hours = orders_per_hour ./ nof_days;
end

